Kodi add-on: hdp_ims
====================
